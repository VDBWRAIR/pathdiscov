/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <boost/thread.hpp>
#include "options.h"
#include "value_type.h"

namespace program_options {

string		input_ref_file;
uint32_t	threads_;
string		database;
string		query_file;
uint32_t	merge_seq_treshold;
uint32_t	block_size;
uint32_t	verbosity;
uint32_t	hit_cap;
int			min_ungapped_raw_score;
uint32_t	shapes;
uint32_t	index_mode;
uint64_t	max_alignments;
string		output_file;
string		match_file1;
string		match_file2;
int			padding;
uint32_t	output_threads;
uint32_t	command;
uint32_t	compression;
uint32_t	lowmem;
int			min_raw_score;
double		chunk_size;
unsigned	min_identities;
unsigned	min_identities2;
int			xdrop;
unsigned	window;
int			min_hit_score;
int			hit_band;
unsigned	min_compressed_identities;
int			min_seed_score;
unsigned	seed_signatures;
double		min_bit_score;
unsigned	run_len;
bool		alignment_traceback;
double		max_seed_freq;
string		tmpdir;
bool		long_mode;
int			gapped_xdrop;
double		max_evalue;
string		sam_output;
string		kegg_file;
unsigned	magic_number;
int			gap_open;
int			gap_extend;
string		matrix;
string		seg;

Aligner_mode aligner_mode;

template<typename _val>
void set_options(double block_size)
{
	/*if(aligner_mode == very_sensitive) {
		set_option(seed_signatures, 2u);
		set_option(hit_cap, 1024u);
		set_option(index_mode, 3u);
		lowmem = std::max(lowmem, 4u);
	} else*/
	if(aligner_mode == sensitive) {
		set_option(seed_signatures, 1u);
		set_option(index_mode, 2u);
		//lowmem = std::max(lowmem, 4u);
	} else if (aligner_mode == fast) {
		set_option(seed_signatures, 1u);
		set_option(index_mode, 1u);
	}

	set_option(chunk_size, block_size);

}

void set_options2(size_t max_query_len, size_t db_letters)
{
	if(aligner_mode == sensitive) {
		set_option(hit_cap, std::max(256u, (unsigned)(db_letters/8735437)));
	} else if (aligner_mode == fast) {
		set_option(hit_cap, std::max(128u, (unsigned)(db_letters/17470874)));
	}

	if(max_query_len <= 40) {
		set_option(min_identities, 10u);
		set_option(min_ungapped_raw_score, 60);
	} else {
		set_option(min_identities, 9u);
		set_option(min_ungapped_raw_score, 50);
	}

	if(max_query_len <= 80) {
		set_option(window, (unsigned)(max_query_len + 5));
		set_option(hit_band, std::max((int)(max_query_len/10), 5));
		set_option(min_hit_score, min_raw_score);
	} else {
		set_option(window, 40u);
		set_option(hit_band, 5);
		set_option(min_hit_score, std::min(65, min_raw_score));
	}
	hit_band = std::min(hit_band, 126);
}

string get_temp_file()
{
	if(strlen(getenv("TMPDIR")) > 0)
		return string(getenv("TMPDIR")) + "/diamond.tmp";
	else {
		std::cerr << "Warning: TMPDIR environment variable not set - using output directory for temporary storage.\n";
		return output_file + ".tmp";
	}
}

unsigned read_padding(size_t len)
{
	static const float padding_factor = 0.15f;
	int p;
	if(padding == 0) {
		p = std::max((unsigned)((float)len*padding_factor), 5u);
	} else
		p = padding;
	return std::min(p, 126);
}

template void set_options<Amino_acid>(double block_size);

bool mem_buffered()
{ return tmpdir == "/dev/shm"; }

}

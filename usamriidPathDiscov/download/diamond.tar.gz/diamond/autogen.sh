#!/bin/sh
autoreconf --force -i -I m4 -I config

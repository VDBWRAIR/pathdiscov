/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef TEXT_BUFFER_H_
#define TEXT_BUFFER_H_

#include <stdlib.h>

struct Text_buffer
{

	Text_buffer():
		data_ (0),
		ptr_ (data_)
	{ }

	void reserve(size_t n)
	{
		const size_t s = ptr_ - data_, new_size = s + n + block_size - ((s+n) & (block_size-1));
		data_ = (char*)realloc(data_, new_size);
		ptr_ = data_ + s;
		if(data_ == 0) throw memory_alloc_exception();
	}

	void operator+=(size_t n)
	{ ptr_ += n; }

	char* get() const
	{ return ptr_; }

	char* get_begin() const
	{ return data_; }

	template<typename _t>
	void write(_t data)
	{
		*reinterpret_cast<_t*>(ptr_) = data;
		ptr_ += sizeof(_t);
	}

	size_t size() const
	{ return ptr_ - data_; }

private:
	enum { block_size = 65536 };
	char *data_, *ptr_;

};

#endif /* TEXT_BUFFER_H_ */

/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef SEQ_FILE_FORMAT_H_
#define SEQ_FILE_FORMAT_H_

using std::pair;

template<typename _val>
struct Sequence_file_format
{

	virtual pair<size_t,size_t> record_length(const char *&data, const char *end) const = 0;
	virtual void get_seq(vector<char> &id, vector<_val> &seq, const char *data, const char *end) const = 0;
	virtual ~Sequence_file_format()
	{ }

protected:

	static size_t skip_line(const char *&data, const char *end)
	{
		size_t n = 0;
		while(data < end && *data != '\n' && *data != '\r') {
			++data;
			++n;
		}
		while(data < end && *data != '\n')
			++data;
		++data;
		data = std::min(data, end);
		return n;
	}

	template<typename _t>
	static void copy_line(const char*& data, const char *end, vector<_t> &v)
	{
		while(data < end && *data != '\n' && *data != '\r')
			v.push_back(Value_traits<_t>::from_char(*(data++)));
		while(data < end && *data != '\n')
			++data;
		++data;
	}

	static size_t skip_until(const char *&data, const char *end, int delimiter)
	{
		size_t n = 0;
		do {
			while(data < end && *data != '\n') {
				if(*data != '\r')
					++n;
				++data;
			}
			++data;
		} while(data < end && *data != delimiter);
		data = std::min(data, end);
		return n;
	}

	static void copy_until(const char *&data, const char *end, int delimiter, vector<_val> &v)
	{
		do {
			while(data < end && *data != '\n') {
				if(*data != '\r')
					v.push_back(Value_traits<_val>::from_char(*data));
				++data;
			}
			++data;
		} while(data < end && *data != delimiter);
	}

	static void skip_char(const char *&data, const char *end, char c)
	{
		if(data >= end || *(data++) != c)
			throw file_format_exception ();
	}

};

template<typename _val>
struct FASTA_format : public Sequence_file_format<_val>
{

	virtual pair<size_t,size_t> record_length(const char *&data, const char *end) const
	{
		Sequence_file_format<_val>::skip_char(data, end, '>');
		const size_t id_len = Sequence_file_format<_val>::skip_line(data, end);
		return pair<size_t,size_t> (id_len, Sequence_file_format<_val>::skip_until(data, end, '>'));
	}

	virtual void get_seq(vector<char> &id, vector<_val> &seq, const char *data, const char *end) const
	{
		Sequence_file_format<_val>::skip_char(data, end, '>');
		id.clear();
		seq.clear();
		Sequence_file_format<_val>::copy_line(data, end, id);
		Sequence_file_format<_val>::copy_until(data, end, '>', seq);
	}

	virtual ~FASTA_format()
	{ }

};

template<typename _val>
struct FASTQ_format : public Sequence_file_format<_val>
{

	virtual pair<size_t,size_t> record_length(const char *&data, const char *end) const
	{
		Sequence_file_format<_val>::skip_char(data, end, '@');
		const size_t id_len = Sequence_file_format<_val>::skip_line(data, end),
				seq_len = Sequence_file_format<_val>::skip_line(data, end);
		Sequence_file_format<_val>::skip_char(data, end, '+');
		Sequence_file_format<_val>::skip_line(data, end);
		Sequence_file_format<_val>::skip_line(data, end);
		return pair<size_t,size_t> (id_len, seq_len);
	}

	virtual void get_seq(vector<char> &id, vector<_val> &seq, const char *data, const char *end) const
	{
		Sequence_file_format<_val>::skip_char(data, end, '@');
		id.clear();
		seq.clear();
		Sequence_file_format<_val>::copy_line(data, end, id);
		Sequence_file_format<_val>::copy_line(data, end, seq);
	}

	virtual ~FASTQ_format()
	{ }

};

template<typename _val>
const Sequence_file_format<_val>* guess_format(const string &file)
{
	static const FASTA_format<_val> fasta;
	static const FASTQ_format<_val> fastq;

	Input_stream f (file);
	char c;
	if(f.read(&c, 1) != 1)
		throw file_format_exception ();
	f.close();
	switch(c) {
	case '>': return &fasta;
	case '@': return &fastq;
	default: throw file_format_exception ();
	}
	return 0;
}

#endif /* SEQ_FILE_FORMAT_H_ */

/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef REORDER_BUFFER_H_
#define REORDER_BUFFER_H_

#include <map>
#include <boost/lockfree/queue.hpp>

using std::map;
using boost::lockfree::queue;
using std::pair;

template<typename _t>
struct reorder_buffer
{

	reorder_buffer():
#ifndef NDEBUG
		input_queue (128),
#endif
		next (0)
	{ }

	void push(unsigned n, const _t &v)
	{ input_queue.push(Pair<unsigned,_t> (n,v)); }

	bool pop(_t &v)
	{
		Pair<unsigned,_t> p;
		while(input_queue.pop(p))
			buffer[p.first] = p.second;

		typename map<unsigned,_t>::iterator i = buffer.begin();
		if(i != buffer.end() && i->first == next) {
			v = i->second;
			buffer.erase(i);
			++next;
			return true;
		} else
			return false;
	}

private:
	queue<Pair<unsigned,_t> >	input_queue;
	map<unsigned,_t>			buffer;
	unsigned					next;

};

#endif /* REORDER_BUFFER_H_ */

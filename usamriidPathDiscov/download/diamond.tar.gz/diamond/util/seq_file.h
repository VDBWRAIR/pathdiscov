/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef SEQ_FILE_H_
#define SEQ_FILE_H_

#include <string>
#include <boost/iostreams/device/mapped_file.hpp>
#include "seq_file_format.h"

using std::string;
using std::pair;

struct MMapped_file : public boost::iostreams::mapped_file_source
{
	MMapped_file(const string &filename)
	{
		this->open(filename.c_str());
		if(!this->is_open())
			THROW_EXCEPTION(file_io_exception, filename);
	}
};

struct Sequence_file : public MMapped_file
{

	template<typename _val>
	Sequence_file(const string &filename, const Sequence_file_format<_val> &format):
		MMapped_file (filename),
		limits_ (this->data(), this->size(), format)
	{ }

	size_t length() const
	{ return limits_.size() - 1; }

	template<typename _val>
	pair<size_t,size_t> record_length(size_t i, const Sequence_file_format<_val> &format) const
	{ const char *ptr = begin(i); return format.record_length(ptr, end(i)); }

	template<typename _val>
	void get_seq(vector<char> &id, vector<_val> &seq, size_t i, const Sequence_file_format<_val> &format) const
	{ format.get_seq(id, seq, begin(i), end(i)); }

private:

	const char* begin(size_t i) const
	{ return this->data() + limits_[i]; }

	const char* end(size_t i) const
	{ return this->data() + limits_[i+1]; }

	struct Limits : public vector<size_t>
	{
		template<typename _val>
		Limits(const char *ptr, size_t size, const Sequence_file_format<_val> &format)
		{
			this->push_back(0);
			const char *ptr2 = ptr, *const end = ptr + size;
			while(ptr2 < end) {
				format.record_length(ptr2, end);
				this->push_back(ptr2 - ptr);
			}
		}
	};

	const Limits limits_;

};

#endif /* SEQ_FILE_H_ */

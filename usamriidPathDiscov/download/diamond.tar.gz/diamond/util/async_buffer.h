/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef ASYNC_BUFFER_H_
#define ASYNC_BUFFER_H_

#include <vector>
#include <boost/thread.hpp>
#include <boost/lockfree/queue.hpp>
#include <boost/iostreams/device/file_descriptor.hpp>
#include <boost/iostreams/device/file.hpp>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/gzip.hpp>

namespace io = boost::iostreams;

using std::vector;
using boost::lockfree::queue;
using boost::thread;

template<typename _t>
struct Async_buffer
{

	typedef vector<_t> Vector;

	Async_buffer(size_t input_count, const string &tmpdir, unsigned bins):
		bins_ (bins),
		bin_size_ ((input_count + bins_ - 1) / bins_),
		writer_thread_ (new thread(writer, this)),
		done_ (false),
		tmpdir_ (tmpdir)
	{
		for(unsigned i=0;i<bins_;++i) {
			//out_[i].push(io::gzip_compressor());
			out_[i].push(io::file_sink (get_file_name(i)));
		}
		memset(size_, 0, sizeof(size_));
	}

	struct Iterator
	{
		Iterator(Async_buffer &parent):
			parent_ (&parent)
		{
			for(unsigned i=0;i<parent_->bins_;++i)
				buffer_[i] = new vector<_t>;
		}
		void push(const _t &x)
		{
			const unsigned bin = x / parent_->bin_size_;
			buffer_[bin]->push_back(x);
			if(buffer_[bin]->size() == buffer_size) {
				parent_->out_queue_[bin].push(buffer_[bin]);
				buffer_[bin] = new vector<_t>;
			}
		}
		~Iterator()
		{
			for(unsigned bin=0;bin<parent_->bins_;++bin)
				parent_->out_queue_[bin].push(buffer_[bin]);
		}
	private:
		vector<_t> *buffer_[Async_buffer<_t>::max_bins];
		Async_buffer *parent_;
	};

	void close()
	{
		done_ = true;
		writer_thread_->join();
		delete writer_thread_;
		for(unsigned i=0;i<bins_;++i) {
			out_[i].set_auto_close(true);
			out_[i].pop();
		}
	}

	void load(vector<_t> &data, unsigned i) const
	{
		data.resize(size_[i]);
		size_t read_size = size_[i] * sizeof(_t);
		if(read_size > 0) {
			io::filtering_istream in;
			//in.push(io::gzip_decompressor());
			in.push(io::file_source(get_file_name(i)));
			if(boost::iostreams::read(in, reinterpret_cast<char*>(data.data()), read_size) != read_size)
				THROW_EXCEPTION(file_io_exception, get_file_name(i));
			in.set_auto_close(true);
			in.pop();
		}
		remove(get_file_name(i).c_str());
	}

	unsigned bins() const
	{ return bins_; }

private:

	enum { buffer_size = 65536 };

	static const unsigned max_bins = 4;

	string get_file_name(unsigned i) const
	{ return tmpdir_ + "/diamond_" + boost::to_string(program_options::magic_number) + "_" + boost::to_string(i) + ".tmp"; }

	void flush_queues()
	{
		vector<_t> *v;
		for(unsigned i=0;i<bins_;++i)
			while(out_queue_[i].pop(v)) {
				size_t write_size = sizeof(_t) * v->size();
				if(boost::iostreams::write(out_[i], reinterpret_cast<const char*>(&v->operator[](0)), write_size) != write_size)
					THROW_EXCEPTION(file_io_write_exception, get_file_name(i));
				size_[i] += v->size();
				delete v;
			}
	}

	static void writer(Async_buffer *me)
	{
		while(!me->done_) {
			me->flush_queues();
			boost::this_thread::sleep_for(boost::chrono::milliseconds(1));
		}
		me->flush_queues();
	}

	const unsigned bins_, bin_size_;
	io::filtering_ostream out_[max_bins];
#ifdef NDEBUG
	queue<vector<_t>*> out_queue_[max_bins];
#else
	queue<vector<_t>*,boost::lockfree::capacity<128> > out_queue_[max_bins];
#endif
	size_t size_[max_bins];
	thread *writer_thread_;
	bool done_;
	const string tmpdir_;

};


template<typename _t>
struct file_async_buffer
{

	typedef typename vector<_t>::iterator iterator;

	file_async_buffer(size_t input_count, const string &tmpdir, unsigned bins):
		bins_ (bins),
		writer_thread_ (new thread(writer, this)),
		bin_size_ ((input_count + bins_ - 1) / bins_),
		done_ (false),
		tmpdir_ (tmpdir)
	{
		for(unsigned i=0;i<bins_;++i) {
			//out_[i].push(io::gzip_compressor());
			out_[i].push(io::file_sink (get_file_name(i)));
		}
		memset(size_, 0, sizeof(size_));
	}

	struct writer_iterator
	{
		writer_iterator(file_async_buffer &parent):
			parent_ (&parent)
		{
			for(unsigned i=0;i<parent_->bins_;++i)
				buffer_[i] = new vector<_t>;
		}
		void push(const _t &x)
		{
			const unsigned bin = x / parent_->bin_size_;
			buffer_[bin]->push_back(x);
			if(buffer_[bin]->size() == buffer_size) {
				parent_->out_queue_[bin].push(buffer_[bin]);
				buffer_[bin] = new vector<_t>;
			}
		}
		~writer_iterator()
		{
			for(unsigned bin=0;bin<parent_->bins_;++bin)
				parent_->out_queue_[bin].push(buffer_[bin]);
		}
	private:
		vector<_t>		    *buffer_[file_async_buffer<_t>::max_bins];
		file_async_buffer	*parent_;
	};

	_t& operator[](size_t i)
	{ return data_[i]; }

	iterator begin()
	{ return data_.begin(); }

	iterator end()
	{ return data_.end(); }

	size_t size() const
	{ return data_.size(); }

	void clear()
	{ data_.clear(); }

	void finish()
	{
		done_ = true;
		writer_thread_->join();
		delete writer_thread_;
		for(unsigned i=0;i<bins_;++i) {
			out_[i].set_auto_close(true);
			out_[i].pop();
		}
	}

	void get_bin(unsigned i)
	{
		data_.resize(size_[i]);
		size_t read_size = size_[i] * sizeof(_t);
		if(read_size > 0) {
			io::filtering_istream in;
			//in.push(io::gzip_decompressor());
			in.push(io::file_source(get_file_name(i)));
			if(boost::iostreams::read(in, reinterpret_cast<char*>(&data_[0]), read_size) != read_size)
				THROW_EXCEPTION(file_io_exception, get_file_name(i));
			in.set_auto_close(true);
			in.pop();
		}
		remove(get_file_name(i).c_str());
		size_[i] = 0;
	}

	unsigned bins() const
	{ return bins_; }

private:

	enum { buffer_size = 65536 };

	static const unsigned max_bins = 4;

	string get_file_name(unsigned i) const
	{ return tmpdir_ + "/diamond_" + boost::to_string(program_options::magic_number) + "_" + boost::to_string(i) + ".tmp"; }

	void flush_queues()
	{
		vector<_t> *v;
		for(unsigned i=0;i<bins_;++i)
			while(out_queue_[i].pop(v)) {
				size_t write_size = sizeof(_t) * v->size();
				if(boost::iostreams::write(out_[i], reinterpret_cast<const char*>(&v->operator[](0)), write_size) != write_size)
					THROW_EXCEPTION(file_io_write_exception, get_file_name(i));
				size_[i] += v->size();
				delete v;
			}
	}

	static void writer(file_async_buffer *me)
	{
		while(!me->done_) {
			me->flush_queues();
			boost::this_thread::sleep_for(boost::chrono::milliseconds(1));
		}
		me->flush_queues();
	}

	const unsigned bins_;
	io::filtering_ostream out_[max_bins];
#ifdef NDEBUG
	queue<vector<_t>*> out_queue_[max_bins];
#else
	queue<vector<_t>*,boost::lockfree::capacity<128> > out_queue_[max_bins];
#endif
	size_t size_[max_bins];
	thread *writer_thread_;
	const unsigned bin_size_;
	bool done_;
	vector<_t> data_;
	const string tmpdir_;

};

#endif /* ASYNC_BUFFER_H_ */

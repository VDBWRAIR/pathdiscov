/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef MATRIX_H_
#define MATRIX_H_

#include <vector>

using std::vector;

template<typename _t>
struct Matrix
{

	Matrix():
		rows_ (0)
	{ }

	Matrix(unsigned columns, unsigned rows):
		rows_ (rows),
		data_ (vector<_t> (columns * rows))
	{ }

	const _t& operator()(unsigned column, unsigned row) const
	{ return data_[column * rows_ + row]; }

	_t* get_column(unsigned i)
	{ return &data_[i * rows_]; }

	unsigned rows_;
	vector<_t> data_;

};

template<typename _t, typename _loc = unsigned>
struct Banded_matrix
{

	Banded_matrix():
		rows_ (0),
		padding_ (0),
		band_ (0),
		columns_ (0),
		data_ (vector<_t> ())
	{ }

	void init(_loc columns, _loc rows, _loc padding, _loc band)
	{
		rows_ = rows;
		padding_ = padding;
		band_ = band;
		columns_ = columns;
		data_.resize((columns+1) * (2*band+1));
	}

	void fill(const _t &x)
	{
		for(typename vector<_t>::iterator i = data_.begin(); i!=data_.end();++i)
			*i = x;
	}

	const _t& operator()(_loc column, _loc row) const
	{
		return data_[column * (2*band_+1) + band_row(column, row)];
	}

	bool in_band(_loc column, _loc row) const
	{
		return column < rows_+padding_ || row >= rows_ - band_;
		/*assert(column < columns_ && column >= 0 && row < rows_ && row >= 0);
		if(column >= rows_ + padding_)
			return row >= rows_ - band_;
		else if(column < padding_)
			return row < band_;
		else
			return row >= column-padding_-band_ && row <= column-padding_+band_;*/
	}

	_loc band_row(_loc column, _loc row) const
	{
		if(column >= rows_ + padding_)
			return row + band_ - rows_;
		else if(column >= padding_) {
			_loc pj = column - padding_;
			return row + band_ - pj;
		} else
			return row + band_ + 1;
	}

	_loc absolute_row(_loc column, _loc band_row) const
	{
		if(column >= rows_ + padding_)
			return band_row + rows_ - band_;
		else if(column >= padding_) {
			_loc pj = column - padding_;
			return band_row + pj - band_;
		} else
			return band_row - band_ - 1;
	}

	_loc band_row_offset(_loc column) const
	{
		if(column >= rows_ + padding_) {
			return 0;
		} else if(column >= padding_) {
			_loc pj (column - padding_);
			return pj >= band_ ? 0 : band_ - pj;
		} else {
			return band_+1;
		}
	}

	_t* get_column(_loc i)
	{ return i>=0 ? &data_[i * (2*band_+1) + band_row_offset(i)] : &data_[columns_ * (2*band_+1) + band_+1]; }

	_loc rows_, padding_, band_, columns_;
	vector<_t> data_;

};

#endif /* MATRIX_H_ */

/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef BINARY_FILE_H_
#define BINARY_FILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <boost/iostreams/device/file_descriptor.hpp>
#include <boost/iostreams/device/file.hpp>
#include <boost/iostreams/filtering_stream.hpp>
//#include <boost/iostreams/filter/gzip.hpp>
#include "../basic/exceptions.h"

namespace io = boost::iostreams;

using std::auto_ptr;
using std::vector;

struct Input_stream : public io::filtering_istream
{

	Input_stream(const string &file_name, bool gzipped = false):
		file_name_ (file_name)
	{
		//if(gzipped)
		//	this->push(io::gzip_decompressor ());
		this->push(io::file_source(file_name));
		if(!this->good())
			THROW_EXCEPTION(file_open_exception, file_name_);
	}

	template<class _t>
	size_t read(_t *ptr, size_t count)
	{
		ssize_t n;
		if((n = io::read(*this, reinterpret_cast<char*>(ptr), sizeof(_t) * count)) != count * sizeof(_t)) {
			if(n == EOF)
				return 0;
			else if(n >= 0 && this->get() == EOF)
				return n/sizeof(_t);
			else
				THROW_EXCEPTION(file_io_exception, file_name_);
		}
		return n/sizeof(_t);
	}

	template<class _t>
	void read(vector<_t> &v)
	{
		size_t size;
		if(read(&size, 1) != 1)
			THROW_EXCEPTION(file_io_exception, file_name_);
		v.resize(size);
		if(read(v.data(), size) != size)
			THROW_EXCEPTION(file_io_exception, file_name_);
	}

	void close()
	{
		this->set_auto_close(true);
		this->pop();
	}

	void remove() const
	{ ::remove(file_name_.c_str()); }

protected:

	const string file_name_;

};

struct Output_stream : io::filtering_ostream
{

	Output_stream(const string &file_name, bool gzipped = false):
		file_name_ (file_name)
	{
		//if(gzipped)
//			this->push(io::gzip_compressor ());
		this->push(io::file_sink(file_name));
		if(!this->good())
			THROW_EXCEPTION(file_open_exception, file_name_);
	}

	template<typename _t>
	void write(const _t *ptr, size_t count)
	{
		if(io::write(*this, reinterpret_cast<const char*>(ptr), sizeof(_t) * count) != sizeof(_t) * count)
			THROW_EXCEPTION(file_io_write_exception, file_name_);
	}

	template<class _t>
	void write(const vector<_t> &v)
	{
		size_t size = v.size();
		write(&size, 1);
		write(v.data(), size);
	}

	void close()
	{
		this->set_auto_close(true);
		this->pop();
	}

private:

	const string file_name_;

};

struct Buffered_file : public Input_stream
{

	Buffered_file(const string& file_name):
		Input_stream (file_name),
		ptr_ (&data_[0]),
		end_ (read_block(ptr_, 2*buffer_size))
	{ }

	bool eof() const
	{ return ptr_ >= end_; }

	template<typename _t>
	void read(_t &dst)
	{
		if(ptr_ + sizeof(_t) > end_)
			THROW_EXCEPTION(file_io_exception, file_name_);
		dst = *reinterpret_cast<_t*>(ptr_);
		ptr_ += sizeof(_t);
	}

	void fetch()
	{
		if(ptr_ >= &data_[buffer_size]) {
			memcpy(&data_[0], &data_[buffer_size], buffer_size);
			ptr_ -= buffer_size;
			end_ -= buffer_size;
			if(end_ == &data_[buffer_size])
				end_ = read_block(&data_[buffer_size], buffer_size);
		}
	}

	const char* ptr() const
	{ return ptr_; }

private:

	char* read_block(char* ptr, size_t size)
	{ return ptr + Input_stream::read(ptr, size); }

	enum { buffer_size = 4096 };

	char data_[2*buffer_size];
	char *ptr_, *end_;

};

#endif /* BINARY_FILE_H_ */

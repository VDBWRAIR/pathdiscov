/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef MAKE_DB_H_
#define MAKE_DB_H_

#include <iostream>
#include "../basic/options.h"
#include "../data/reference.h"
#include "../basic/exceptions.h"
#include "../basic/statistics.h"
#include "../data/load_seqs.h"
#include "../util/seq_file.h"
#include "../util/seq_file_format.h"

template<class _val>
void make_db(_val)
{
	using std::cout;
	using std::endl;

	if(program_options::verbosity >= 1)
		cout << "Database file = " << program_options::input_ref_file << endl;

	task_timer timer ("Opening the database file", 1);
	Sequence_file db_file (program_options::input_ref_file, FASTA_format<_val> ());
	timer.finish();

	ref_cfg.long_addressing = false;
	ref_cfg.build = Const::build_version;
	ref_cfg.letters = 0;
	ref_cfg.sequences = 0;
	ref_cfg.block_size = program_options::chunk_size;
	size_t file_offset = 0, chunk = 0;
	Output_stream main(program_options::database_file_name());
	main.write(&ref_cfg, 1);

	for(;file_offset < db_file.length();++chunk) {
		timer.go("Loading sequences", 1, 2);
		size_t n_seq = load_seqs<_val,_val>(db_file, FASTA_format<_val>(), file_offset, ref_seqs<_val>::data_, ref_ids, (size_t)(program_options::chunk_size * 1e9));
		if(n_seq == 0)
			break;
		file_offset += n_seq;
		ref_cfg.letters += ref_seqs<_val>::data_->letters();
		ref_cfg.sequences += n_seq;
		const bool long_addressing = ref_seqs<_val>::data_->raw_len() >= 1ll<<32;
		ref_cfg.long_addressing = ref_cfg.long_addressing == true ? true : long_addressing;
		timer.finish();
		ref_seqs<_val>::data_->print_stats();

		timer.go("Building histograms", 1);
		seed_histogram *hst = new seed_histogram (*ref_seqs<_val>::data_, _val());

		timer.go("Saving to disk", 1);
		ref_seqs<_val>::data_->save(main);
		ref_ids->save(main);
		main.write(hst, 1);

		timer.go("Deallocating sequences", 1);
		delete ref_seqs<_val>::data_;
		delete ref_ids;
		delete hst;
	}

	timer.finish();
	ref_cfg.n_blocks = chunk;
	main.seekp(0);
	main.write(&ref_cfg, 1);
	main.close();

	if(program_options::verbosity >= 1)
		cout << "Total time = " << boost::timer::format(timer.elapsed(), 1, "%ws\n");
}

#endif /* MAKE_DB_H_ */

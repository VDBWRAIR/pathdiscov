/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef MASTER_THREAD_H_
#define MASTER_THREAD_H_

#include <iostream>
#include <boost/thread.hpp>
#include <boost/timer/timer.hpp>
#include "../data/reference.h"
#include "../data/queries.h"
#include "../basic/statistics.h"
#include "../basic/shape_config.h"
#include "../output/join_blocks.h"
#include "../util/seq_file.h"
#include "../align/align_queries.h"
#include "../search/align_range.h"

using std::endl;
using std::cout;
using boost::thread;
using boost::timer::cpu_timer;
using boost::ptr_vector;

template<typename _val, typename _locr, typename _locq, typename _locl>
void process_shape(unsigned sid,
		cpu_timer &timer_mapping,
		unsigned query_chunk,
		unsigned ref_chunk,
		char *query_buffer,
		char *ref_buffer)
{
	using std::vector;
	using boost::atomic;

	::partition p (Const::seedp, program_options::lowmem);
	for(unsigned chunk=0;chunk < p.parts; ++chunk) {

		if(program_options::verbosity >= 1)
			cout << "=== Processing query chunk " << query_chunk << ", reference chunk " << ref_chunk << ", shape " << sid << ", index chunk " << chunk << " ===" << endl;
		const seedp_range range (p.getMin(chunk), p.getMax(chunk));
		current_range = range;

		task_timer timer ("Building reference index", 1, 2);
		typename sorted_list<_locr>::Type ref_idx (ref_buffer,
				*ref_seqs<_val>::data_,
				shape_config::instance.get_shape(sid),
				ref_hst.get(program_options::index_mode, sid),
				range);
		ref_masking.build<_val,_locr>(sid, range, ref_idx);

		timer.go("Building query index", 1, 2);
		timer_mapping.resume();
		typename sorted_list<_locq>::Type query_idx (query_buffer,
				*query_seqs<_val>::data_,
				shape_config::instance.get_shape(sid),
				query_hst->get(program_options::index_mode, sid),
				range);
		timer.finish();

		timer.go("Searching alignments", 1);
#pragma omp parallel
		{
			Statistics stat;
#pragma omp for schedule(dynamic) nowait
			for(unsigned seedp=0;seedp<Const::seedp;++seedp) {
				align_partition<_val,_locr,_locq,_locl>(seedp,
						stat,
						sid,
						ref_idx.get_partition_cbegin(seedp),
						query_idx.get_partition_cbegin(seedp));
			}
#pragma omp critical
			statistics += stat;
		}

	}
	timer_mapping.stop();
}

template<typename _val, typename _locr, typename _locq, typename _locl>
void run_ref_chunk(Input_stream &db_file,
		cpu_timer &timer_mapping,
		cpu_timer &total_timer,
		unsigned query_chunk,
		unsigned ref_chunk,
		size_t max_query_len,
		char *query_buffer)
{
	task_timer timer ("Loading reference sequences", 1);
	ref_seqs<_val>::data_ = new Sequence_set<_val> (db_file);
	ref_ids = new String_set<char,0> (db_file);
	db_file.read(&ref_hst, 1);
	program_options::set_options2(max_query_len, ref_seqs<_val>::data_->letters());

	timer.go("Initializing temporary storage", 1);
	timer_mapping.resume();
	Trace_pt_buffer<_locr,_locl>::instance = new Trace_pt_buffer<_locr,_locl> (query_seqs<_val>::data_->get_length()/6,
			program_options::tmpdir,
			program_options::mem_buffered());

	timer.go("Allocating buffers", 1);
	char *ref_buffer = sorted_list<_locr>::Type::alloc_buffer(ref_hst);
	timer.finish();
	timer_mapping.stop();

	for(unsigned i=0;i<shape_config::instance.count();++i)
		process_shape<_val,_locr,_locq,_locl>(i, timer_mapping, query_chunk, ref_chunk, query_buffer, ref_buffer);

	timer.go("Deallocating buffers", 1);
	delete[] ref_buffer;

	timer_mapping.resume();
	vector<Output_stream*> out;
	if(ref_cfg.n_blocks > 1) {
		timer.go ("Opening temporary output files", 1);
		for(unsigned i=0;i<Output_stack<_val>::get().size();++i)
			out.push_back(new Temp_output_file (i, ref_chunk, program_options::tmpdir));
	} else {
		for(typename Output_stack<_val>::iterator i = Output_stack<_val>::get().begin(); i != Output_stack<_val>::get().end(); ++i)
			out.push_back(&i->master_file);
	}

	timer.go("Closing temporary storage", 1);
	Trace_pt_buffer<_locr,_locl>::instance->close();

	timer.go("Computing alignments", 1, 2);
	align_queries<_val,_locr,_locl>(*Trace_pt_buffer<_locr,_locl>::instance, out);
	delete Trace_pt_buffer<_locr,_locl>::instance;

	if(ref_cfg.n_blocks > 1) {
		timer.go("Closing the output files", 1);
		for(vector<Output_stream*>::iterator i = out.begin(); i != out.end(); ++i) {
			(*i)->close();
			delete *i;
		}
	}
	timer_mapping.stop();

	timer.go("Deallocating reference", 1);
	delete ref_seqs<_val>::data_;
	delete ref_ids;
	timer.finish();
}

template<typename _val, typename _locr, typename _locq, typename _locl>
void run_query_chunk(Input_stream &db_file,
		cpu_timer &timer_mapping,
		cpu_timer &total_timer,
		unsigned query_chunk,
		size_t max_query_len)
{
	task_timer timer ("Allocating buffers", 1);
	char *query_buffer = sorted_list<_locq>::Type::alloc_buffer(*query_hst);
	timer.finish();

	db_file.seekg(sizeof(reference_config));
	for(unsigned ref_chunk=0;ref_chunk<ref_cfg.n_blocks;++ref_chunk)
		run_ref_chunk<_val,_locr,_locq,_locl>(db_file, timer_mapping, total_timer, query_chunk, ref_chunk, max_query_len, query_buffer);

	timer.go("Deallocating buffers", 1);
	timer_mapping.resume();
	delete[] query_buffer;

	timer.go("Deallocating queries", 1);
	delete query_seqs<_val>::data_;
	delete query_ids;

	if(ref_cfg.n_blocks > 1) {
		timer.go("Joining output blocks", 1);
		join_blocks(ref_cfg.n_blocks, Output_stack<_val>::get());
	}
	timer_mapping.stop();
}

template<typename _val, typename _locr>
void master_thread(Input_stream &db_file, cpu_timer &timer_mapping, cpu_timer &total_timer)
{
	shape_config::instance = shape_config (program_options::index_mode, Amino_acid());

	task_timer timer ("Opening the input file", 1);
	timer_mapping.resume();
	const Sequence_file_format<Nucleotide> *format (guess_format<Nucleotide>(program_options::query_file));
	Sequence_file query_file (program_options::query_file, *format);
	current_query_chunk=0;
	size_t query_file_offset = 0;

	timer.go("Opening the output files", 1);
	Output_stack<_val>::get().template add<Blast_tab_format<_val> >(program_options::output_file);
	Output_stack<_val>::get().template add<Sam_format<_val> >(program_options::sam_output);
	timer_mapping.stop();
	timer.finish();

	for(;query_file_offset < query_file.length();++current_query_chunk) {

		task_timer timer ("Loading query sequences", 1, 2);
		timer_mapping.resume();
		size_t n_query_seqs = load_seqs<Nucleotide,_val>(query_file, *format, query_file_offset, query_seqs<_val>::data_, query_ids, (size_t)(program_options::chunk_size * 1e9));
		query_file_offset += n_query_seqs;
		if(n_query_seqs == 0)
			break;
		timer.finish();
		if(program_options::verbosity >= 3)
			query_seqs<_val>::data_->print_stats();

		timer.go("Building query histograms", 1);
		query_hst = auto_ptr<seed_histogram> (new seed_histogram (*query_seqs<_val>::data_, _val()));
		const size_t max_query_len = query_seqs<_val>::data_->max_len();
		if(max_query_len > Const::max_query_len)
			throw input_sequence_length_exception();
		timer_mapping.stop();
		timer.finish();
		const bool long_addressing_query = query_seqs<_val>::data_->raw_len() > (size_t)std::numeric_limits<uint32_t>::max();

		if(max_query_len < 256) {
			if(long_addressing_query)
				run_query_chunk<_val,_locr,uint64_t,uint8_t>(db_file, timer_mapping, total_timer, current_query_chunk, max_query_len);
			else
				run_query_chunk<_val,_locr,uint32_t,uint8_t>(db_file, timer_mapping, total_timer, current_query_chunk, max_query_len);
		} else {
			if(long_addressing_query)
				run_query_chunk<_val,_locr,uint64_t,uint16_t>(db_file, timer_mapping, total_timer, current_query_chunk, max_query_len);
			else
				run_query_chunk<_val,_locr,uint32_t,uint16_t>(db_file, timer_mapping, total_timer, current_query_chunk, max_query_len);
		}

	}

	timer.go("Closing the output files", 1);
	timer_mapping.resume();
	Output_stack<_val>::get().close_all();
	timer_mapping.stop();

	timer.go("Closing the database file", 1);
	db_file.close();

	timer.finish();
	if(program_options::verbosity >= 1) {
		cout << "Total time = " << boost::timer::format(total_timer.elapsed(), 1, "%ws\n");
		cout << "Mapping time = " << boost::timer::format(timer_mapping.elapsed(), 1, "%ws\n");
	}
	statistics.print();
}

template<typename _val>
void master_thread()
{
	cpu_timer timer2, timer_mapping;
	timer_mapping.stop();

	task_timer timer ("Opening the database", 1);
	Input_stream db_file (program_options::database_file_name());
	db_file.read(&ref_cfg, 1);
	if(ref_cfg.build > Const::build_version || ref_cfg.build < Const::build_compatibility)
		throw invalid_database_version_exception();
	timer.finish();
	program_options::set_options<_val>(ref_cfg.block_size);
	if(program_options::verbosity >= 1) {
		cout << "Reference = " << program_options::database << endl;
		cout << "Sequences = " << ref_cfg.sequences << endl;
		cout << "Letters = " << ref_cfg.letters << endl;
		cout << "Block size = " << (size_t)(ref_cfg.block_size * 1e9) << endl;
	}

	if(ref_cfg.long_addressing)
		master_thread<_val,uint64_t>(db_file, timer_mapping, timer2);
	else
		master_thread<_val,uint32_t>(db_file, timer_mapping, timer2);
}

#endif /* MASTER_THREAD_H_ */

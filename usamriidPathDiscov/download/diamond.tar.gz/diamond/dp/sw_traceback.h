/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef SSE_SW_TRACEBACK_H_
#define SSE_SW_TRACEBACK_H_

#include <assert.h>
#include <vector>
#ifdef __SSE4_1__
#include <smmintrin.h>
#endif
#include <boost/thread/tss.hpp>
#include "../util/matrix.h"

using std::vector;
using std::cout;
using std::endl;
using boost::thread_specific_ptr;

// #define SW_ENABLE_DEBUG

struct SW_traceback { };

template<typename _score, typename _tb_tag>
struct Traceback_info
{

	Traceback_info(const unsigned, const unsigned, unsigned, unsigned)
	{ }

	void set_traceback_vector(const score_vector<_score> &cell, const score_vector<_score> &cmp) const
	{ }

	void set_best(const score_vector<_score> &cell, const score_vector<_score> &cmp) const
	{ }

	void reset_column(const unsigned, const score_vector<_score> &best, const score_vector<_score> &column_best) const
	{ }

	template<typename _val, typename _f>
	void invoke_callback(_f &f, int i, const sequence<const _val> &seq, int score, unsigned channel, const sequence<const _val> &query, unsigned padding, Statistics &stats) const
	{ f(i, seq, score); }

};

template<typename _score>
struct Traceback_info<_score, SW_traceback>
{

	struct Cell
	{
		Cell():
			zero (0),
			hgap (0),
			vgap (0),
			hopen (0),
			vopen (0)
		{ }
		uint16_t zero, hgap, vgap, hopen, vopen;
	} __attribute__ ((packed));

	struct Cell_position
	{
		Cell_position():
			subject_pos (0),
			query_pos (0)
		{ }
		Cell_position(const unsigned subject_pos, const unsigned query_pos):
			subject_pos (subject_pos),
			query_pos (query_pos)
		{ }
		unsigned subject_pos;
		unsigned query_pos;
	};

	void set_traceback_vector(const score_vector<_score> &cell, const score_vector<_score> &cmp)
	{ *(cell_ptr_++) = cell.cmpeq(cmp); }

	static void tls_init()
	{
		if(!vector_ptr.get())
			vector_ptr.reset(new Banded_matrix<Cell> ());
	}

	Traceback_info(const unsigned query_len, const unsigned subject_len, unsigned padding, unsigned band):
		vector_ ((tls_init(), *vector_ptr.get())),
		column_max_ (_mm_set1_epi8(0xff))
	{
		vector_.init(subject_len, query_len, padding, band);
		cell_ptr_ = reinterpret_cast<uint16_t*>(vector_.get_column(0));
		row_ = _mm_set1_epi8(vector_.band_row_offset(0));
	}

	void reset_column(const unsigned i, const score_vector<_score> &best, const score_vector<_score> &column_best)
	{
		uint8_t c[16];
		_mm_storeu_si128(reinterpret_cast<__m128i*>(c), column_max_);
		for(unsigned j=0;j<16;++j)
			if(column_best[j] > best[j])
				best_pos_[j] = Cell_position (i, vector_.absolute_row(i, c[j]));
		column_max_ = _mm_set1_epi8(0xff);
		row_ = _mm_set1_epi8(vector_.band_row_offset(i+1));
		cell_ptr_ = reinterpret_cast<uint16_t*>(vector_.get_column(i+1));
	}

	void set_best(const score_vector<_score> &cell, const score_vector<_score> &cmp)
	{
		__m128i mask = cell.cmpeq2(cmp);
		#ifdef __SSE4_1__
		column_max_ = _mm_blendv_epi8(column_max_, row_, mask);
		#else
		column_max_ = _mm_or_si128(_mm_and_si128(mask, row_), _mm_andnot_si128(mask, column_max_));
		#endif
		row_ = _mm_add_epi8(row_, _mm_set1_epi8(1));
	}

	template<typename _val>
	local_match<_val> get(const unsigned channel,
			const sequence<const _val> &query,
			const sequence<const _val> &subject,
			unsigned padding) const
	{
		//static char qstring[1024], sstring[1024];
		//char *q (qstring), *s (sstring);

		unsigned channel_mask (1 << channel * score_traits<_score>::byte_size);
		unsigned subject_end = best_pos_[channel].subject_pos;
		unsigned query_end = best_pos_[channel].query_pos;

		local_match<_val> l;
		Edit_transcript *transcript = new Edit_transcript ();
		l.transcript_ = transcript;
		unsigned i = subject_end;
		unsigned j = query_end;
		int score = 0;

		while(vector_.in_band(i, j) && !zero(channel_mask, i, j) && i > 0 && j > 0) {

			if(hgap(channel_mask, i, j)) {
				++l.gap_openings_;
				score -= program_options::gap_open;
				do {
					//*(q++) = '-';
					//*(s++) = subject[i];
					--i;
					++l.len_;
					score -= program_options::gap_extend;
					transcript->push_back(Edit_transcript::deletion);
				} while(!hopen(channel_mask, i, j));
			} else if(vgap(channel_mask, i, j)) {
				++l.gap_openings_;
				score -= program_options::gap_open;
				do {
					//*(q++) = query[j];
					//*(s++) = '-';
					--j;
					++l.len_;
					score -= program_options::gap_extend;
					transcript->push_back(Edit_transcript::insertion);
				} while(!vopen(channel_mask, i, j));
			} else {
				if(query[j] == mask_critical(subject[i]))
					++l.identities_;
				else
					++l.mismatches_;
				//*(q++) = query[j];
				//*(s++) = subject[i];
				score += score_matrix::get().letter_score(query[j], mask_critical(subject[i]));
				--i;
				--j;
				++l.len_;
				transcript->push_back(Edit_transcript::match);
			}

		}

		if(!zero(channel_mask, i, j)) {
			if(query[j] == mask_critical(subject[i]))
				++l.identities_;
			else
				++l.mismatches_;
			//*(q++) = query[j];
			//*(s++) = subject[i];
			score += score_matrix::get().letter_score(query[j], mask_critical(subject[i]));
			++l.len_;
			transcript->push_back(Edit_transcript::match);
		} else {
			++j;
			++i;
		}
		l.query_len_ = query_end - j + 1;
		l.subject_len_ = subject_end - i + 1;
		l.query_begin_ = j;
		l.subject_begin_ = (int)i - padding;
		l.score_ = score;

		/*while(q > qstring)
			cout << *(--q);
		cout << endl;
		while(s > sstring)
			cout << *(--s);
		cout << endl;
		cout << score << endl;*/

		return l;
	}

	template<typename _val, typename _f>
	void invoke_callback(_f &f, int i, const sequence<const _val> &seq, int score, unsigned channel, const sequence<const _val> &query, unsigned padding, Statistics &stats) const
	{
		local_match<_val> l = get<_val>(channel, query, seq, padding);
		f(i, seq, l.score_, l);
	}

private:

	bool hgap(uint16_t channel_mask, unsigned i, unsigned j) const
	{ return vector_(i, j).hgap & channel_mask; }

	bool vgap(uint16_t channel_mask, unsigned i, unsigned j) const
	{ return vector_(i, j).vgap & channel_mask; }

	bool hopen(uint16_t channel_mask, unsigned i, unsigned j) const
	{ return vector_(i, j).hopen & channel_mask; }

	bool vopen(uint16_t channel_mask, unsigned i, unsigned j) const
	{ return vector_(i, j).vopen & channel_mask; }

	bool zero(uint16_t channel_mask, unsigned i, unsigned j) const
	{ return vector_(i, j).zero & channel_mask; }

	static thread_specific_ptr<Banded_matrix<Cell> > vector_ptr;
	Banded_matrix<Cell> &vector_;
	uint16_t *cell_ptr_;
	Cell_position best_pos_[score_traits<_score>::channels];
	__m128i column_max_, row_;

};

template<typename _score>
thread_specific_ptr<Banded_matrix<typename Traceback_info<_score, SW_traceback>::Cell> > Traceback_info<_score, SW_traceback>::vector_ptr;

#endif /* SSE_SW_TRACEBACK_H_ */

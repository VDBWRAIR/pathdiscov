/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef LOAD_SEQS_H_
#define LOAD_SEQS_H_

#include "sequence_set.h"
#include "../basic/translate.h"
#include "../util/complexity_filter.h"
#include "../util/seq_file.h"

using boost::thread;
using boost::atomic;

template<typename _ival> unsigned get_grouping()
{ return 1; }

template<> unsigned get_grouping<Nucleotide>()
{ return 6; }

template<typename _ival, typename _val>
size_t ss_reserve(String_set<_val> &ss, size_t l)
{ ss.reserve(l); return l; }

template<>
size_t ss_reserve<Nucleotide,Amino_acid>(String_set<Amino_acid> &ss, size_t l)
{
	if(l < 2) {
		for(unsigned i=0;i<6;++i)
			ss.reserve(0);
		return 0;
	}
	size_t n = 0;
	n += ss.reserve(l/3);
	n += ss.reserve((l-1)/3);
	n += ss.reserve((l-2)/3);
	n += ss.reserve(l/3);
	n += ss.reserve((l-1)/3);
	n += ss.reserve((l-2)/3);
	return n;
}

template<typename _ival, typename _val>
void set_seq(String_set<_val> &ss, size_t i, const vector<_ival> &seq, bool masking)
{ ss.set(i, seq); }

template<>
void set_seq<Nucleotide,Amino_acid>(String_set<Amino_acid> &ss, size_t i, const vector<Nucleotide> &seq, bool masking)
{
	if(seq.size() < 2) {
		for(unsigned j=0;j<6;++j)
			ss.fill(i*6+j, Value_traits<Amino_acid>::MASK_CHAR);
		return;
	}
	vector<Amino_acid> proteins[6];
	size_t length_ (seq.size()), d;
	proteins[0].resize(d = length_ / 3);
	proteins[3].resize(d);
	proteins[1].resize(d = (length_-1) / 3);
	proteins[4].resize(d);
	proteins[2].resize(d = (length_-2) / 3);
	proteins[5].resize(d);

	Translator::translate(seq, proteins);
	unsigned run_len = program_options::run_len;
	if(run_len == 0) {
		if(length_/3 < 100)
			run_len = 20;
		else
			run_len = 40;
	}

	unsigned bestFrames (Translator::computeGoodFrames(proteins, run_len));
	for(unsigned j = 0; j < 6; ++j) {
		const size_t masked = masking ? ::Complexity_filter<Amino_acid>::get().filter(proteins[j]) : 0;
		if((bestFrames & (1 << j)) && (proteins[j].size() - masked) >= run_len)
			ss.set(i*6+j, proteins[j]);
		else
			ss.fill(i*6+j, Value_traits<Amino_acid>::MASK_CHAR);
	}
}

template<typename _ival, typename _val>
void build_seqs(const Sequence_file *file,
		const Sequence_file_format<_ival> *format,
		size_t offset,
		size_t begin,
		size_t end,
		Sequence_set<_val> *seqs,
		String_set<char,0> *ids,
		bool masking)
{
	vector<_ival> seq;
	vector<char> id;

	for(size_t i=begin;i<end;++i) {
		file->get_seq(id, seq, offset + i, *format);
		ids->set(i, id);
		set_seq<_ival,_val>(*seqs, i, seq, masking);
	}
}

template<typename _ival, typename _val>
size_t load_seqs(const Sequence_file &file,
		const Sequence_file_format<_ival> &format,
		size_t offset,
		Sequence_set<_val>*& seqs,
		String_set<char,0>*& ids,
		size_t max_letters)
{
	static const unsigned my_verbosity = 3;

	task_timer timer ("Reading input limits", my_verbosity);
	seqs = new Sequence_set<_val> ();
	ids = new String_set<char,0> ();
	size_t letters = 0, n = 0;

	while(offset + n < file.length() && letters < max_letters) {
		const pair<size_t,size_t> lengths = file.record_length(n + offset, format);
		ids->reserve(lengths.first);
		letters += ss_reserve<_ival,_val>(*seqs, lengths.second);
		++n;
	}

	timer.go("Allocating buffers", my_verbosity);
	seqs->finish_reserve();
	ids->finish_reserve();

	if(n == 0) {
		delete seqs;
		delete ids;
		return 0;
	}

	timer.go("Loading input sequences", my_verbosity);
	::partition p (::partition(n, program_options::threads()));
	bool masking = program_options::seg == "yes";
#pragma omp parallel for schedule(dynamic)
	for(unsigned i=0;i<p.parts;++i)
		build_seqs<_ival,_val>(&file, &format, offset, p.getMin(i), p.getMax(i), seqs, ids, masking);

	return n;
}

#endif /* LOAD_SEQS_H_ */

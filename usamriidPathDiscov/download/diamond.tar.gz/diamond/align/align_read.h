/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef ALIGN_READ_H_
#define ALIGN_READ_H_

#include <vector>
#include <assert.h>
#include "../util/async_buffer.h"
#include "../basic/match.h"
#include "../basic/statistics.h"
#include "../search/align_ungapped.h"
#include "align_sequence.h"
#include "traceback.h"
#include "../util/text_buffer.h"
#include "../output/output_buffer.h"
#include "../output/output_stack.h"

using std::vector;

template<typename _val, typename _locr, typename _locl>
struct align_read
{

	align_read(Output_buffers &buffers, Statistics &stat):
		buffers_ (buffers),
		stat_ (stat)
	{ }

	void operator()(typename Trace_pt_buffer<_locr,_locl>::Vector::iterator &begin, typename Trace_pt_buffer<_locr,_locl>::Vector::iterator &end)
	{
		static thread_specific_ptr<vector<local_match<_val> > > local_ptr;
		static thread_specific_ptr<vector<match<_val> > > matches_ptr;

		if(!(begin < end))
			return;

		Tls<vector<match<_val> > > matches (matches_ptr);
		Tls<vector<local_match<_val> > > local (local_ptr);
		local->clear();
		matches->clear();

		const size_t hit_count = end - begin;
		local->reserve(hit_count);
		const unsigned query (begin->query_/6);
		const size_t query_len (query_seqs<_val>::data_->length(query*6));
		const size_t dna_len (query_seqs<_val>::data_->dna_len(query*6));
		const size_t db_letters = ref_cfg.letters;

		bool onepass_traceback = program_options::long_mode
				|| (program_options::alignment_traceback
				&& query_len > Const::onepass_traceback_len
				&& (hit_count <= program_options::max_alignments));
		unsigned padding[6];

		align_sequence<_val,_locr,_locl> as (*matches, stat_, *local, onepass_traceback, padding, db_letters);
		split_container(begin, end, as, typename hit<_locr,_locl>::query_frame());

		if(matches->size() == 0)
			return;

		std::sort(matches->begin(), matches->end());

		if(program_options::alignment_traceback && !onepass_traceback) {
			for(unsigned i = 0; i < 6; ++i) {
				const sequence<const _val> query_seq = query_seqs<_val>::data_->operator[](query*6 + i);
				padding[i] = program_options::read_padding(query_seq.length());
				traceback<_val>(query_seq,
						i,
						*local,
						matches->begin(),
						std::min(matches->begin() + program_options::max_alignments, matches->end()),
						padding[i],
						stat_);
			}
		}

		const sequence<const char> query_name = query_ids->operator[](query);
		unsigned n_hsp = 0, n_target_seq = 0;
		typename vector<match<_val> >::iterator it = matches->begin();

		while(it < matches->end() && (n_target_seq < program_options::max_alignments)) {
			transform_match(*it, dna_len, padding[it->frame_]);
			for(unsigned i=0;i<buffers_.size();++i) {
				Output_buffer &buf = *buffers_[i];
				buf.set_meta_info(query, it->subject_id_, it->evalue_);
				buf.reserve(Output_stack<_val>::get()[i].max_line_size);
				buf += Output_stack<_val>::get()[i].format.print_match(buf.get(), *it, db_letters, query_len, dna_len, query_name, padding[it->frame_], query_seqs<_val>::data_->operator[](query*6 + it->frame_));
				buf.set_terminator();
			}

			++n_hsp;
			if(!program_options::long_mode || it == matches->begin() || (it-1)->subject_id_ != it->subject_id_)
				++n_target_seq;
			if(program_options::alignment_traceback && it->traceback_->gap_openings_ > 0)
				stat_.inc(Statistics::GAPPED);
			++it;
		}

		if(program_options::alignment_traceback)
			for(typename vector<match<_val> >::iterator it = matches->begin(); it != matches->end(); ++it)
				if(it->traceback_)
					delete it->traceback_->transcript_;

		stat_.inc(Statistics::OUT_MATCHES, matches->size());
		if(ref_cfg.n_blocks == 1) {
			stat_.inc(Statistics::MATCHES, n_hsp);
			stat_.inc(Statistics::ALIGNED);
		}

	}

private:
	Output_buffers &buffers_;
	Statistics &stat_;

};

#endif /* ALIGN_READ_H_ */

/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef ALIGN_SEQUENCE_H_
#define ALIGN_SEQUENCE_H_

#include <vector>
#include <boost/thread/tss.hpp>
#include "../dp/smith_waterman.h"

using boost::thread_specific_ptr;
using std::vector;

template<typename _val, typename _locr, typename _locl>
struct align_sequence
{

	align_sequence(vector<match<_val> > &matches, Statistics &stat, vector<local_match<_val> > &local, bool traceback, unsigned *padding, size_t db_letters):
		matches_ (matches),
		stat_ (stat),
		frame_ (0),
		local_ (local),
		traceback_ (traceback),
		padding_ (padding),
		query_len_ (0),
		db_letters_ (db_letters)
	{ }

	void operator()(typename Trace_pt_buffer<_locr,_locl>::Vector::iterator &begin, typename Trace_pt_buffer<_locr,_locl>::Vector::iterator &end)
	{
		static thread_specific_ptr<vector<sequence<const _val> > > subjects_ptr;

		std::sort(begin, end, hit<_locr,_locl>::cmp_normalized_subject);
		Tls<vector<sequence<const _val> > > subjects (subjects_ptr);
		const unsigned q_num (begin->query_);
		const sequence<const _val> query (query_seqs<_val>::data_->operator[](q_num));
		frame_ = q_num % 6;
		query_len_ = query.length();
		padding_[frame_] = program_options::read_padding(query_len_);

		const Sequence_set<_val> *ref = ref_seqs<_val>::data_;
		subjects->clear();
		for(typename Trace_pt_buffer<_locr,_locl>::Vector::iterator i = begin; i != end; ++i) {
			if(i != begin && (i->global_diagonal() - (i-1)->global_diagonal()) <= padding_[frame_]) {
				stat_.inc(Statistics::DUPLICATES);
				continue;
			}
			subjects->push_back(ref->padded_infix(i->subject_, i->seed_offset_, query_len_, padding_[frame_]));
			stat_.inc(Statistics::OUT_HITS);
		}

		if(subjects->size() == 0)
			return;

		if(traceback_)
			smith_waterman(query,
					*subjects,
					padding_[frame_],
					padding_[frame_],
					program_options::gap_open + program_options::gap_extend,
					program_options::gap_extend,
					program_options::min_raw_score,
					*this,
					uint8_t(),
					SW_traceback(),
					stat_,
					true);
		else
			smith_waterman(query,
					*subjects,
					padding_[frame_],
					padding_[frame_],
					program_options::gap_open + program_options::gap_extend,
					program_options::gap_extend,
					program_options::min_raw_score,
					*this,
					uint8_t(),
					0,
					stat_,
					true);
	}

	void operator()(int i, const sequence<const _val> &seq, int score) const
	{
		matches_.push_back(match<_val> (seq, score, frame_, score_matrix::get().evalue(score, db_letters_, query_len_)));
	}

	void operator()(unsigned i, const sequence<const _val> &subject, int score, local_match<_val> l) const
	{
		local_.push_back(l);
		matches_.push_back(match<_val> (subject, score, frame_, score_matrix::get().evalue(score, db_letters_, query_len_), &local_.back()));
	}

private:

	vector<match<_val> >	&matches_;
	Statistics				&stat_;
	unsigned				 frame_;
	vector<local_match<_val> >	&local_;
	const bool				 traceback_;
	unsigned				*padding_;
	unsigned				 query_len_;
	const size_t			 db_letters_;

};

#endif /* ALIGN_SEQUENCE_H_ */

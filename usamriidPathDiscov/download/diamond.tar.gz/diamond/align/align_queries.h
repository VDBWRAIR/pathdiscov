/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef ALIGN_QUERIES_H_
#define ALIGN_QUERIES_H_

#if __GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 3)
#include <parallel/algorithm>
#else
#include <algorithm>
#endif
#include "../search/trace_pt_buffer.h"
#include "../util/reorder_buffer.h"
#include "align_read.h"

using std::vector;
using boost::thread;

struct Output_piece
{
	Output_piece():
		text (),
		size ()
	{ }
	Output_piece(char *text, size_t size):
		text (text),
		size (size)
	{ }
	char *text;
	size_t size;
};

typedef boost::ptr_vector<reorder_buffer<Output_piece> > Output_queues;

void flush_queue(const vector<Output_stream*> *output_files, Output_queues *out_queues)
{
	Output_piece out_buf;
	for(unsigned i=0;i<out_queues->size();++i) {
		while(out_queues->operator[](i).pop(out_buf)) {
			if(out_buf.text != 0)
				output_files->operator[](i)->write(out_buf.text, out_buf.size);
			free(out_buf.text);
		}
	}
}

void write_worker(bool *done, const vector<Output_stream*> *output_files, Output_queues *out_queue)
{
	while(!*done) {
		flush_queue(output_files, out_queue);
		boost::this_thread::sleep_for(boost::chrono::milliseconds(1));
	}
}

template<typename _val, typename _locr, typename _locl>
void align_queries(typename Trace_pt_buffer<_locr,_locl>::Vector &trace_pts, const vector<Output_stream*> &output_files)
{
	if(trace_pts.size() == 0)
		return;
	bool done = false;
	const vector<size_t> p = map_partition(trace_pts.begin(), trace_pts.end(), hit<_locr,_locl>::input_id, 65536, 4096, program_options::threads()*4);
	Output_queues out_queues;
	for(unsigned i=0;i<output_files.size();++i)
		out_queues.push_back(new reorder_buffer<Output_piece>);
	thread* writer = new thread(write_worker, &done, &output_files, &out_queues);

#pragma omp parallel
	{
		Statistics st;
#pragma omp for schedule(dynamic) nowait
		for(unsigned i=0;i<p.size()-1;++i) {
			size_t begin = p[i], end = p[i+1];
			while(begin < end && trace_pts[begin].blank())
				++begin;
			Output_buffers buffers = Output_stack<_val>::get().get_buffers();
			if(end > begin) {
				align_read<_val,_locr,_locl> ar (buffers, st);
				split_container(trace_pts.begin() + begin, trace_pts.begin() + end, ar, typename hit<_locr,_locl>::input_query());
			}
			for(unsigned j=0;j<buffers.size();++j)
				out_queues[j].push(i, Output_piece(buffers[j]->get_begin(), buffers[j]->size()));
		}
#pragma omp critical
		statistics += st;
	}

	done = true;
	writer->join();
	delete writer;
	flush_queue(&output_files, &out_queues);
}

template<typename _val, typename _locr, typename _locl>
void align_queries(const Trace_pt_buffer<_locr,_locl> &trace_pts, const vector<Output_stream*> &output_files)
{
	typename Trace_pt_buffer<_locr,_locl>::Vector v;
	Output_stack<_val>::get().set_line_sizes(max_id_len(*query_ids), max_id_len(*ref_ids), query_seqs<_val>::data_->max_len());
	for(unsigned bin=0;bin<trace_pts.bins();++bin) {
		if(program_options::verbosity >= 3)
			printf("Processing query bin %u/%u.\n", bin+1, trace_pts.bins());
		task_timer timer ("Loading trace points", 3);
		trace_pts.load(v, bin);
		timer.go("Sorting trace points", 3);
#if __GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 3)
		__gnu_parallel::sort(v.begin(), v.end());
#else
		merge_sort(v.begin(), v.end(), program_options::threads());
#endif
		timer.go("Computing alignments", 3);
		align_queries<_val,_locr,_locl>(v, output_files);
	}
}

#endif /* ALIGN_QUERIES_H_ */

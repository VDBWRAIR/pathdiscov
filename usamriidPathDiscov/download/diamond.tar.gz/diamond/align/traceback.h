/****
Copyright (c) 2014, University of Tuebingen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****
Author: Benjamin Buchfink
****/

#ifndef TRACEBACK_H_
#define TRACEBACK_H_

#include <vector>
#include <boost/thread/tss.hpp>
#include "../basic/match.h"
#include "../dp/smith_waterman.h"

using std::vector;
using boost::thread_specific_ptr;

template<typename _val>
struct F_traceback
{
	F_traceback(vector<match<_val>*> &match_ptr, vector<local_match<_val> > &out):
		match_ptr_ (match_ptr),
		out_ (out)
	{ }
	void operator()(unsigned i, const sequence<const _val> &subject, int score, local_match<_val> l)
	{
		out_.push_back(l);
		match_ptr_[i]->traceback_ = &out_.back();
		match_ptr_[i]->score_ = l.score_;
	}
	vector<match<_val>*> &match_ptr_;
	vector<local_match<_val> > &out_;
};

template<typename _val>
void traceback(const sequence<const _val> &query,
		unsigned frame,
		vector<local_match<_val> > &out,
		typename vector<match<_val> >::iterator begin,
		typename vector<match<_val> >::iterator end,
		unsigned padding,
		Statistics &stats)
{
	static thread_specific_ptr<vector<sequence<const _val> > > subjects_ptr;
	static thread_specific_ptr<vector<match<_val>*> > match_ptr;

	Tls<vector<sequence<const _val> > > subjects (subjects_ptr);
	Tls<vector<match<_val>*> > matches (match_ptr);
	subjects->clear();
	matches->clear();

	for(typename vector<match<_val> >::iterator i = begin; i < end; ++i) {

		if(i->frame_ != frame)
			continue;

		ungapped_match ug = align_ungapped(query, i->subject_.aligned_data(padding), i->subject_.aligned_clip(padding));

		assert(i->traceback_ == 0);
		//assert(ug.score_ <= i->score_);
		if(ug.score_ >= i->score_) {
			out.push_back(ug.parse(query, i->subject_.aligned_data(padding)));
			i->traceback_ = &out.back();
		} else {
			subjects->push_back(i->subject_);
			matches->push_back(&*i);
		}

	}

	if(subjects->size() == 0)
		return;

	F_traceback<_val> f (*matches, out);
	smith_waterman(query,
			*subjects,
			padding,
			padding,
			program_options::gap_open + program_options::gap_extend,
			program_options::gap_extend,
			0,
			f,
			uint8_t(),
			SW_traceback(),
			stats,
			true);
}

#endif /* TRACEBACK_H_ */

class TestAttrib:
    @staticmethod
    def test_static():
        pass

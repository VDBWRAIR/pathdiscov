def moo():
    print 'covered'

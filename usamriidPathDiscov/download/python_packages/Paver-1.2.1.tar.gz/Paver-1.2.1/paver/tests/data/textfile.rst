This is an example file that will use cog to include stuff.

For example, here's some Python code::

    # [[[cog include('t2.py', 'second') ]]]
    # [[[end]]]
    
It should be included there. We'll see.

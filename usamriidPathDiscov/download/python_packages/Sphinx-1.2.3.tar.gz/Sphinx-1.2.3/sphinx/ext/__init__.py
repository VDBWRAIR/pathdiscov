# -*- coding: utf-8 -*-
"""
    sphinx.ext
    ~~~~~~~~~~

    Contains Sphinx features not activated by default.

    :copyright: Copyright 2007-2014 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

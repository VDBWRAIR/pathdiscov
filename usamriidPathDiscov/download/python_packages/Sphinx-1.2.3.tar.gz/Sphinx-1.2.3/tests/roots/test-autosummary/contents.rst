
.. autosummary::
   :nosignatures:
   :toctree:

   dummy_module

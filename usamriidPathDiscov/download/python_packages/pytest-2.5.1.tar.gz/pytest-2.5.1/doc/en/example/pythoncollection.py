
# run this with $ py.test --collect-only test_collectonly.py
#
def test_function():
    pass

class TestClass:
    def test_method(self):
        pass
    def test_anothermethod(self):
        pass
